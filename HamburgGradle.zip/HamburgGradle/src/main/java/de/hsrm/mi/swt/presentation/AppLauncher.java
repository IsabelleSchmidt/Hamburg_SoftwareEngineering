package de.hsrm.mi.swt.presentation;

import javafx.application.Application;

public class AppLauncher {
	
	public static void main(String[] args) {
		Application.launch(VerkehrssimulationMain.class);
	}

}
