package business.validator;

public class Validator {

}
