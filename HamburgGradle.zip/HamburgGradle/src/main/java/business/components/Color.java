package business.components;

public enum Color {

	PINK,BLUE,GREEN,BLACK,RED
}
