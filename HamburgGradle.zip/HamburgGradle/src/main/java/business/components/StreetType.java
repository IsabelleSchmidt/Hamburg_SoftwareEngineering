package business.components;

public enum StreetType {
	CURVE, CROSSING, STRAIGHT, JUNCTION
}
