package business.components;

public enum Direction {

	LEFT, RIGHT, UP, DOWN

}
