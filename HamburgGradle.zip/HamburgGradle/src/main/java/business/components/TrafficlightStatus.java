package business.components;

public enum TrafficlightStatus {
	RED, ORANGE, ORANGEGREEN, GREEN;

}
